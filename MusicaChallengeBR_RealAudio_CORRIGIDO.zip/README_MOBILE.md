# Música Challenge BR — APK pelo celular

Esta versão usa um catálogo de **músicas brasileiras reais como referência de jogo**, incluindo funk, sertanejo, trap/pagode e hits.

Importante: os nomes dos artistas/músicas não significam que os áudios comerciais estejam embutidos no APK. O app não copia nem distribui MP3 protegidos. Para tocar áudio comercial de verdade, é necessário integrar um serviço/player que permita essa reprodução.

## Gerar o APK pelo celular

1. Crie uma conta no GitHub.
2. Crie um repositório novo.
3. Envie todos os arquivos deste projeto, incluindo `.github/workflows/build-apk.yml`.
4. Abra **Actions**.
5. Entre em **Gerar APK**.
6. Toque em **Run workflow**.
7. Espere o check verde.
8. Abra a execução concluída.
9. Em **Artifacts**, baixe `MusicaChallenge-APK`.
10. Extraia o ZIP e instale `app-debug.apk` no Android.

## Catálogo inicial

- Leão — Marília Mendonça
- Ai Preto — L7NNON & DJ Biel do Furduncinho
- Tá OK — DENNIS & Kevin O Chris
- Nosso Quadro — Ana Castela
- Erro Gostoso — Simone Mendes
- Canudinho — Gusttavo Lima & Ana Castela
- PocPoc — Pedro Sampaio
- Haverá Sinais — Jorge & Mateus
- MTG - Quem Não Quer Sou Eu — DJ Topo
- Casca de Bala — Thullio Milionário

A próxima etapa é conectar cada rodada a uma fonte de reprodução autorizada e fazer o desafio reconhecer a música.


### Correção de compilação
Esta versão está configurada para compilar Java e Kotlin com JVM 17, compatível com o ambiente do GitHub Actions.
