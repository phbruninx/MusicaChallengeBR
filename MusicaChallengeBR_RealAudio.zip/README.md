# Música Challenge BR

Protótipo Android inspirado na interface da referência enviada pelo usuário.

A versão BR traz um catálogo inicial de músicas brasileiras reais como dados do jogo, incluindo funk e outros gêneros populares. Os áudios comerciais não são distribuídos dentro do APK.

Para gerar o APK usando somente o celular, consulte README_MOBILE.md.
