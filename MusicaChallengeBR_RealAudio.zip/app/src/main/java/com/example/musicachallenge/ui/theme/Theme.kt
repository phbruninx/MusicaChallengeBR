package com.example.musicachallenge.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Scheme = darkColorScheme(
    primary = Color(0xFF25E77B),
    onPrimary = Color.Black,
    background = Color(0xFF050908),
    surface = Color(0xFF101615),
    surfaceVariant = Color(0xFF151B1A),
    onSurface = Color.White,
    onSurfaceVariant = Color(0xFF9DA8A5)
)

@Composable
fun MusicaChallengeTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
